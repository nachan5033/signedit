import fontforge
from bdflib import reader
import fakenp as np



font_size = 180 #1000 for opentype, 1024 for truetype

def getStrokes(font : np.ndarray):
    h, w = font.shape
    hmap = np.zeros((h + 1, w + 1))
    vmap = np.zeros((h + 1, w + 1))
    
    RIGHT = DOWN = 1
    LEFT = UP = -1
    
    PROCESSED = 2
    
    NO_MOVE = 0
    GO_RIGHT = 1
    GO_LEFT = 2
    GO_UP = 3
    GO_DOWN = 4
    
    for y in range(h):
        for x in range(w):
            if font[y, x] == 1:
                hmap[y    , x] += RIGHT
                hmap[y + 1, x] += LEFT
                vmap[y    , x] += UP
                vmap[y, x + 1] += DOWN
    
    strokes = []
    processed = hmap.copy()
    #find contours:
    for y0 in range(h):
        for x0 in range(w):
            last_move = NO_MOVE
            previous_move = NO_MOVE
            x = x0
            y = y0
            if hmap[y, x] == RIGHT and processed[y, x] != PROCESSED:
                #can go right here
                x = x0 + 1
                contour = [(x0,y0),(x,y)]
            
                processed[y0, x0] = PROCESSED
                last_move = GO_RIGHT
                while (x,y) != contour[0]:
                    previous_move = last_move
                    if last_move == GO_RIGHT: #tries to go down soon
                        if vmap[y,x] == DOWN:
                            y += 1; last_move = GO_DOWN
                        elif vmap[y-1,x] == UP and y >= 1:
                            y -= 1; last_move = GO_UP
                        elif hmap[y,x] == RIGHT and x < w:
                            processed[y,x] = PROCESSED
                            x += 1; last_move = GO_RIGHT
                            
                        else:
                            raise AssertionError('Unexpected end of path')
                    elif last_move == GO_DOWN: #tries to go left soon
                        if x >= 1 and hmap[y, x-1] == LEFT:
                            processed[y, x-1] = PROCESSED
                            x -= 1; last_move = GO_LEFT
                        elif hmap[y,x] == RIGHT:
                            processed[y, x] = PROCESSED
                            x += 1; last_move = GO_RIGHT
                        elif vmap[y,x] == DOWN and y < h:
                            y += 1; last_move = GO_DOWN
                        else:
                            raise AssertionError('Unexpected end of path')
                    elif last_move == GO_LEFT: #tries to go up soon
                        if y >= 1 and vmap[y-1, x] == UP:
                            y -= 1; last_move = GO_UP
                        elif vmap[y,x] == DOWN and y < h:
                            y += 1; last_move = GO_DOWN
                        elif x >= 1 and hmap[y,x-1] == LEFT:
                            processed[y, x-1] = PROCESSED
                            x -= 1; last_move = GO_LEFT
                        else:
                            raise AssertionError('Unexpected end of path')
                    elif last_move == GO_UP: #tries to go right soon
                        if x <= w and hmap[y,x] == RIGHT:
                            processed[y, x] = PROCESSED
                            x += 1; last_move = GO_RIGHT
                        elif x >= 1 and hmap[y,x-1] == LEFT:
                            processed[y, x-1] = PROCESSED
                            x -= 1; last_move = GO_LEFT
                        elif y >= 1 and vmap[y-1, x] == UP:
                            y -= 1; last_move = GO_UP
                        else:
                            raise AssertionError('Unexpected end of path')
                    
                    oldx, oldy  = contour[-1]
                    assert oldx != x or oldy != y
                    if previous_move == last_move:
                        contour[-1] = (x, y)
                    else:
                        contour.append((x, y))
                strokes.append(contour)
    return strokes

def bitmapFromBDF(bdf_glyph : str):
    x = y = 0
    lines = bdf_glyph.split('\n')
    w = len(lines[0])
    h = len(lines)
    font = np.zeros((18, 18), dtype=np.uint8)
    for c in bdf_glyph:
        if c == '#':
            font[y,x] = 1
            x += 1
        elif c == '\n':
            x = 0
            y += 1
        else:
            x += 1
    return font

def toTTFCoord(x, y,bbx,bby,bbH, px):
    global font_size
    x1 = (x + bbx)*px
    y1 = (bbH - y + bby)*px
    
    return x1,y1

def bdf2ttf(bdfpath : str, ttfpath: str):
    global font_size
    with open(bdfpath, 'rb') as fp_bdf:
        bdf = reader.read_bdf(fp_bdf)
        
        font = fontforge.font()
        font.encoding = 'unicode'
        
 
        char_count = bdf.properties[b'DEFAULT_CHAR']

        pixel_size = bdf.properties[b'PIXEL_SIZE']
        
        px = int(font_size / pixel_size)
        font.ascent = bdf.properties[b'FONT_ASCENT']*px
        font.descent = bdf.properties[b'FONT_DESCENT']*px
        print('%d characters found'%char_count)
        print('Character in %d px'%px)
        
        old_progress = 0
        i = 0
        for glyph in bdf.glyphs:
            ttf_glyph = font.createMappedChar(glyph.codepoint)
            ttf_glyph = font[glyph.codepoint]
            
            #x_offset = glyph.bbX
            #y_offset = glyph.bbY
            
            bbx = glyph.bbX
            bby = glyph.bbY
            bbh = glyph.bbH

            
            pen = ttf_glyph.glyphPen()
            #build the bitmap from str
            fnt = bitmapFromBDF(glyph.__str__())
            strokes = getStrokes(fnt)

            for stroke in strokes:
                x,y = stroke[0]
                #x += x_offset
                #y -= y_offset #bbY and y is in different coord
                
                x1,y1 = toTTFCoord(x,y,bbx,bby,bbh,px)
                pen.moveTo((x1,y1))
                for point in stroke[1:-1]:
                    x,y = point
                    #x += x_offset
                    #y -= y_offset
                    
                    x1,y1 = toTTFCoord(x,y,bbx,bby,bbh,px)
                    pen.lineTo((x1,y1))
                    if glyph.codepoint == 0x4e3f:
                        print(x1,y1)
                pen.closePath()
            
            pen = None
            ttf_glyph.removeOverlap()
            ttf_glyph.width = glyph.bbW*px
            ttf_glyph.vwidth = glyph.bbH*px
            
            if ttf_glyph.width == 0:
                print('0 width at%x'%glyph.codepoint)
            if glyph.codepoint == 0x4e3f:
                print(glyph.bbW)
                print(glyph.bbX)
                print(ttf_glyph.width)
                fnt.print()
            
            #calculate the left and right side bearing of the glyph
            #due to the limitation of the lib, do it manually
            ttf_glyph.left_side_bearing = 10
            ttf_glyph.right_side_bearing = int(px)
            
            i += 1
            progress = int(i*100 / char_count)
            if progress != old_progress and progress %10 == 0:
                print('Processing character {}/{} ({}%)'.format(i, char_count, progress))
                old_progress = progress

        
        font.save('D:\Projects\mcwrite\\font\\unimc.sfd')
        
def main():    
    bdf2ttf('D:\Projects\mcwrite\\font\\test.bdf','')

if __name__ == '__main__':
    main()