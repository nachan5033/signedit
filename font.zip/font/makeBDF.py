from getopt import getopt, GetoptError
import sys
import cv2 as cv
import io
import numpy as np

def png2bdf(pngpath : str, tablepath : str):
    png = cv.imread(pngpath, cv.IMREAD_UNCHANGED)
    b,g,r,alpha = cv.split(png)
    result = ''

    charset = []
    lines = []
    with open(tablepath, 'r') as f:
        lines = f.readlines()
    for line in lines:
        chars = line.split('\\u')
        charset.append(chars[1:]) #skip the first char ''

    tablewidth = len(charset[0])
    tableheight = len(charset)

    h,w = alpha.shape
    charh = int(h / tableheight)
    charw = int(w / tablewidth)

    for i in range(0,tableheight):
        for j in range(0,tablewidth):
            x = j * charw
            y = i * charh
            char = alpha[y:y+charh,x:x+charw]
            code = charset[i][j]

def writeBDFHeader(fp : io.TextIOWrapper, charcount : int,fontfamily = 'unifontmc',bold = False):
    fp.write('STARTFONT 2.1\n')
    if bold:
        fp.write('FONT %s-bold\n' % fontfamily)
    else:
        fp.write('FONT %s-normal\n' % fontfamily)

    fp.write('SIZE 18 75 75\n')
    fp.write('FONTBOUNDINGBOX 18 16 0 -2\n')
    fp.write('STARTPROPERTIES 13\n')
    fp.write('FAMILY_NAME "%s"\n' % fontfamily)
    if bold:
        fp.write('WEIGHT_NAME "Bold"\n')
        #fp.write('PIXEL_SIZE 20\n')
    else:
        fp.write('WEIGHT_NAME "Medium"\n')
        #fp.write('PIXEL_SIZE 16\n')
    fp.write('PIXEL_SIZE 18\n')
    fp.write('POINT_SIZE 160\n')
    fp.write('RESOLUTION_X 75\n')
    fp.write('RESOLUTION_Y 75\n')
    fp.write(
    """CHARSET_REGISTRY "ISO10646"
CHARSET_ENCODING "1"
UNDERLINE_POSITION -2
UNDERLINE_THICKNESS 1
FONT_ASCENT 14
FONT_DESCENT 2
DEFAULT_CHAR %d\n"""%charcount)
    fp.write('ENDPROPERTIES\n')
    fp.write('CHARS %d\n'%charcount)

def scanHex(hex_fp : io.TextIOWrapper):
    char = 0
    line = hex_fp.readline()
    while line:
        code, font = line.split(':')
        if line != '' and len(code) <= 4:
            char += 1
        line = hex_fp.readline()
    hex_fp.seek(0)
    return char

def previewHex(hexstr : str, code = 0x00, bold = False, shift = False):
    pointer = 0x80000000
    print('|0  1  2  3  4  5  6  7  8  9  10 11 12 13 14 15 b  |')
    font: list[int] = [0x00000000] * 16
    bitskip = 0  # how many empty bits should be skipped when calculating the position of the char
    if len(hexstr) == 32:  # width = 8 px
        for i in range(16):
            font[i] = int(hexstr[i * 2: i * 2 + 2], 16)
        bitskip = 24
    elif len(hexstr) == 64:
        for i in range(16):
            font[i] = int(hexstr[i * 4: i * 4 + 4], 16)
        bitskip = 16
    elif True:  # fix bug of pycharm
        print('Format error!')
        raise ValueError('Wrong format!')

    if shift:
        left_bound = 15
        right_bound = 0
        seeker_left = 0x80000000  # 1000 0000...

        # calculating bounding box
        # CJK
        if (0x2e80 <= code <= 0x2eff) or (0x2f00 <= code <= 0x2fdf) or (0x3000 <= code <= 0x30ff) \
                or (0x3190 <= code <= 0x319f) or (0x3200 <= code <= 0x4dff) or (0x4e00 <= code <= 0x9fff):
            left_bound = 0
            right_bound = 15
        else:
            for line in font:
                i = bitskip
                while i < 32:
                    if line & seeker_left >> i:  # a pixel found
                        if (i - bitskip) < left_bound: left_bound = i - bitskip
                        if (i - bitskip) > right_bound: right_bound = i - bitskip
                    i += 1

        if left_bound == 15: left_bound = 0  # empty character
        if right_bound == 0: right_bound = 15
        assert right_bound >= left_bound
        # shift the glyph to left
        for i in range(16):
            font[i] = font[i] << left_bound

    if bold:
        for i in range(16):
            font[i] = (font[i] << 8) | (font[i] << 7)
        bitskip -= 8
    for line in font:
        print('|',end='')
        for i in range(32 - bitskip):
            if (pointer >> (i + bitskip)) & line:
                print('███',end='')
            else:
                print('   ',end='')
        print('|')
    print('|0  1  2  3  4  5  6  7  8  9  10 11 12 13 14 15 b  |')

def writeCharToBDF(bdf_fp : io.TextIOWrapper, code : int, hexstr : str ,bold = False):
    font : list[int] = [0x00000000]*16
    bdf_fp.write('STARTCHAR U+%04X\n'%code)
    bdf_fp.write('ENCODING %d\n'%code)

    bitskip = 0 #how many empty bits should be skipped when calculating the position of the char
    if len(hexstr) == 32:#width = 8 px
        for i in range(16):
            font[i] = int(hexstr[i * 2: i * 2 + 2], 16)
        bitskip = 24
    elif len(hexstr) == 64:
        for i in range(16):
            font[i] = int(hexstr[i * 4: i * 4 + 4], 16)
        bitskip = 16
    elif True: #fix bug of pycharm
        print('Format error!')
        raise ValueError('Wrong format at %04X'%code)

    left_bound = 15
    right_bound = 0
    seeker_left = 0x80000000 #1000 0000...

    #calculating bounding box
    #CJK
    if (0x2e80 <= code <= 0x2eff) or (0x2f00 <= code <= 0x2fdf) or (0x3000 <= code <= 0x30ff)\
        or (0x3190 <= code <= 0x319f) or (0x3200 <= code <= 0x4dff) or (0x4e00 <= code <= 0x9fff):
        left_bound = 0
        right_bound = 15
    else:
        for line in font:
            i = bitskip
            while i < 32:
                if line & seeker_left >> i: #a pixel found
                    if (i - bitskip) < left_bound: left_bound = i - bitskip
                    if (i - bitskip) > right_bound: right_bound = i - bitskip
                i += 1

    if left_bound == 15 : left_bound = 0 #empty character
    if right_bound == 0 : right_bound = 15
    assert right_bound >= left_bound

    #shift the glyph to left
    for i in range(16):
        font[i] = font[i] << left_bound

    #auto bold
    if bold:
        right_bound += 1
        for i in range(16):
            font[i] = font[i] << 8 | (font[i] << 7)

    # writing glyph info
    charwidth = right_bound - left_bound + 1
    assert charwidth <= 17

    #bdf_fp.write('SWIDTH 1000 0\n')
    bdf_fp.write('SWIDTH %d 0\n' % int((charwidth + 1) / 18 * 1000))
    bdf_fp.write('DWIDTH %d 0\n' % (charwidth + 1))
    bdf_fp.write('BBX %d 16 0 -2\n' % charwidth)
    #bdf_fp.write('BBX 18 18 0 -2\n')


    #writing glyph
    bdf_fp.write('BITMAP\n')
    if not bold:
        if bitskip == 24: #8bit per line:
            for i in range(16):
                bdf_fp.write('%02X' % font[i])
                if charwidth >= 8:
                    bdf_fp.write('00')  # padding to avoid bug
                bdf_fp.write('\n')

        else: #16 bit per line
            for i in range(16):
                bdf_fp.write('%04X'%font[i])
                if charwidth >= 16:
                    bdf_fp.write('0000')  # padding to avoid bug
                bdf_fp.write('\n')
    else: #bold
        if bitskip == 24:  # 8bit per line:
            for i in range(16):
                bdf_fp.write('%04X' % font[i])
                if charwidth >= 8:
                    bdf_fp.write('0000')  # padding to avoid bug
                bdf_fp.write('\n')

        else:  # 16 bit per line
            for i in range(16):
                bdf_fp.write('%06X00\n' % font[i])

    bdf_fp.write('ENDCHAR\n')
    #print(left_bound, right_bound)



    if bold:
        pass
    else:
        pass

def hex2bdf(hexpath : str, bdfpath : str,family : str, bold = False):
    with open(bdfpath,'w') as fp_bdf:
        with open(hexpath,'r') as fp_hex:
            print('Scanning hex file...')
            char_count = scanHex(fp_hex)
            print('Found %d character(s)...' % char_count)

            writeBDFHeader(fp_bdf, char_count,fontfamily=family, bold=bold)
            line = fp_hex.readline()
            i = 0
            last_progress = 0
            while line:
                codestr, fontstr = line.split(':')
                if fontstr.endswith('\n'): fontstr = fontstr[:-1]
                if len(codestr) != 4 :
                    line = fp_hex.readline()
                    continue
                unicode = int(codestr,16)
                writeCharToBDF(fp_bdf, unicode, fontstr,bold)
                i += 1

                progress = int(i*100 / char_count)
                if progress%10 == 0 and progress != last_progress:
                    print('Progress %d%%'%progress)
                    last_progress = progress

                line = fp_hex.readline()
            fp_bdf.write('ENDFONT')
                #write to bdf



def help():
    print('Usage : python makeBDF.py [options]')
    print('Options:')
    print('  <-h>: show this help message and exit')
    print('  [-i]: input file, .hex or .png')
    print('  [-o]: output file, .bdf')
    print('  <-t>: or --table: char table')
    print('  <-a>: add data to existing file')
    print('  <-f>: specify font family')
    print('')
    print('  -b: bold mode')
    exit(1)

def main(argv):
    inputfile = ''
    outputfile = ''
    table = ''
    fontfamily = 'unimc'
    bold = False
    opt = []
    try:
        opt,args = getopt(argv[1:],'hi:o:t:f:b','table=')
    except GetoptError:
        help()

    for opt, arg in opt:
        if opt == '-h':
            help()
        elif opt == '-i':
            inputfile = arg
        elif opt == '-o':
            outputfile = arg
        elif opt == '-t':
            table = arg
        elif opt == '--table':
            table = arg
        elif opt == '-b':
            bold = True
            print('Bold mode')
        elif opt == '-f':
            fontfamily = arg

    if inputfile.endswith('.hex'):
        hex2bdf(inputfile, outputfile,fontfamily,bold)
    elif inputfile.endswith('.png'):
        pass
    print('nothing')
if __name__ == '__main__':

    #previewHex('AAAA00018000000180004A51EA505A51C99E0001800000018000000180005555',False)
    #writeCharToBDF(sys.stdout,0x0000,'AAAA00018000000180004A51EA505A51C99E0001800000018000000180005555', True)
    main(sys.argv)