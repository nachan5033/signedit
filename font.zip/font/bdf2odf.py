import io
from bdflib import reader
import numpy as np


def getStrokes(font : np.ndarray):
    h, w = font.shape
    hmap = np.zeros((h + 1, w + 1))
    vmap = np.zeros((h + 1, w + 1))

    
    RIGHT = DOWN = 1
    LEFT = UP = -1
    
    PROCESSED = 2
    
    NO_MOVE = 0
    GO_RIGHT = 1
    GO_LEFT = 2
    GO_UP = 3
    GO_DOWN = 4
    
    for y in range(h):
        for x in range(w):
            if font[y, x] == 1:
                hmap[y    , x] += RIGHT
                hmap[y + 1, x] += LEFT
                vmap[y    , x] += UP
                vmap[y, x + 1] += DOWN
    
    strokes = []
    processed = hmap.copy()
    #find contours:
    for y0 in range(h):
        for x0 in range(w):
            last_move = NO_MOVE
            previous_move = NO_MOVE
            x = x0
            y = y0
            if hmap[y, x] == RIGHT and processed[y, x] != PROCESSED:
                #can go right here
                x = x0 + 1
                contour = [(x0,y0),(x,y)]
            
                processed[y0, x0] = PROCESSED
                last_move = GO_RIGHT
                while (x,y) != contour[0]:
                    previous_move = last_move
                    if last_move == GO_RIGHT: #tries to go down soon
                        if vmap[y,x] == DOWN:
                            y += 1; last_move = GO_DOWN
                        elif vmap[y-1,x] == UP and y >= 1:
                            y -= 1; last_move = GO_UP
                        elif hmap[y,x] == RIGHT and x < w:
                            assert processed[y,x] != PROCESSED
                            processed[y,x] = PROCESSED
                            x += 1; last_move = GO_RIGHT
                            
                        else:
                            raise AssertionError('Unexpected end of path')
                    elif last_move == GO_DOWN: #tries to go left soon
                        if x >= 1 and hmap[y, x-1] == LEFT and processed[y,x-1] != PROCESSED:
                            processed[y, x-1] = PROCESSED
                            x -= 1; last_move = GO_LEFT
                        elif hmap[y,x] == RIGHT and processed[y,x] != PROCESSED:
                            processed[y, x] = PROCESSED
                            x += 1; last_move = GO_RIGHT
                        elif vmap[y,x] == DOWN and y < h:
                            y += 1; last_move = GO_DOWN
                        else:
                            raise AssertionError('Unexpected end of path')
                    elif last_move == GO_LEFT: #tries to go up soon
                        if y >= 1 and vmap[y-1, x] == UP:
                            y -= 1; last_move = GO_UP
                        elif vmap[y,x] == DOWN and y < h:
                            y += 1; last_move = GO_DOWN
                        elif x >= 1 and hmap[y,x-1] == LEFT:
                            assert processed[y,x-1] != PROCESSED
                            processed[y, x-1] = PROCESSED
                            x -= 1; last_move = GO_LEFT
                        else:
                            raise AssertionError('Unexpected end of path')
                    elif last_move == GO_UP: #tries to go right soon
                        if x <= w and hmap[y,x] == RIGHT and processed[y,x] != PROCESSED:
                            processed[y, x] = PROCESSED
                            x += 1; last_move = GO_RIGHT
                        elif x >= 1 and hmap[y,x-1] == LEFT and processed[y,x-1] != PROCESSED:
                            processed[y, x-1] = PROCESSED
                            x -= 1; last_move = GO_LEFT
                        elif y >= 1 and vmap[y-1, x] == UP:
                            y -= 1; last_move = GO_UP
                        else:
                            raise AssertionError('Unexpected end of path')
                    
                    oldx, oldy  = contour[-1]
                    assert oldx != x or oldy != y
                    if previous_move == last_move:
                        contour[-1] = (x, y)
                    else:
                        contour.append((x, y))

                strokes.append(contour)

    return strokes

def bitmapFromBDF(bdf_glyph : str):
    x = y = 0
    lines = bdf_glyph.split('\n')
    w = len(lines[0])
    h = len(lines)
    font = np.zeros((h, w), dtype=np.uint8)
    for c in bdf_glyph:
        if c == '#':
            font[y,x] = 1
            x += 1
        elif c == '\n':
            x = 0
            y += 1
        else:
            x += 1
    return font

def toTTFCoord(x, y,bbx,bby,bbH, px):
    x1 = (x + bbx)*px
    y1 = (bbH - y + bby)*px

def bdf2odf(bdf_path,odf_path,name,scale : int = 1):
    with open(bdf_path, 'rb') as fp:
        with open(odf_path, 'w') as odf_fp:
            bdf = reader.read_bdf(fp)
            char_count = bdf.properties[b'DEFAULT_CHAR']
            pixel_size = bdf.properties[b'PIXEL_SIZE']
            ascent = bdf.properties[b'FONT_ASCENT']
            descent = bdf.properties[b'FONT_DESCENT']
            
            print('%d characters found'%char_count)
            print('Character in %d px'%pixel_size)
            
            odf_fp.write('FONT %s\n' % name)
            odf_fp.write('SCALE %d\n' % scale)
            odf_fp.write('ASCENT %d\n' % ascent*scale)
            odf_fp.write('DESCENT %d\n' % descent*scale)
            
            old_progress = 0
            i = 0
            for glyph in bdf.glyphs:
                bbx = glyph.bbX
                bby = glyph.bbY
                bbh = glyph.bbH
                code = glyph.codepoint
                odf_fp.write('FONT %x\n')
                fnt = bitmapFromBDF(glyph.__str__())
                strokes = getStrokes(fnt)
                
                for stroke in strokes: 
                    x,y = stroke[0]









            


