#Fuck FontForge

class ndarray:
    def __init__(self,shape):
        self.shape=shape
        w,h = shape
        
        self.data = [[0]*h for i in range(w)]
    
    def __getitem__(self,key):
        return self.data[key[0]][key[1]]
    
    def __setitem__(self,key,value):
        self.data[key[0]][key[1]] = value
    
    def copy(self):
        n = ndarray(self.shape)
        for i in range(self.shape[0]):
            n.data[i] = self.data[i].copy()

        return n

    def print(self):
        print(self.data)
        for line in self.data:
            print(line)




uint8 = None

def zeros(shape,dtype=None):
    return ndarray(shape)







        
