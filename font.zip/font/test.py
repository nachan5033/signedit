import cv2 as cv
import numpy as np
from bdflib import reader

px = 25

drawx = 0
drawy = 0
count = 0

def bitmapFromBDF(bdf_glyph : str):
    x = y = 0
    lines = bdf_glyph.split('\n')
    w = len(lines[0])
    h = len(lines)
    font = np.zeros((h, w), dtype=np.uint8)
    for c in bdf_glyph:
        if c == '#':
            font[y,x] = 1
            x += 1
        elif c == '\n':
            x = 0
            y += 1
        else:
            x += 1
    return font

def prev(hmap : np.ndarray,img: np.ndarray, vmap : np.ndarray | None = None):
    for y in range(17):
        for x in range(17):
            if hmap[y,x] == 1:
                cv.arrowedLine(img,(x*px,y*px),(x*px+px,y*px),(255,0,0),thickness=2,tipLength=0.2)
            if hmap[y,x] == -1:
                cv.arrowedLine(img,(x*px+px,y*px),(x*px,y*px),(0,0,255),thickness=2,tipLength=0.2)
            if hmap[y,x] == 2:
                cv.line(img,(x*px,y*px),(x*px+px,y*px),(0,255,255),thickness=2)
            if vmap is not None and vmap[y,x] == 1:
                cv.arrowedLine(img,(x*px,y*px),(x*px,y*px+px),(0,255,0),thickness=2,tipLength=0.2)
            if vmap is not None and vmap[y,x] == -1:
                cv.arrowedLine(img,(x*px,y*px+px),(x*px,y*px),(0,255,0),thickness=2,tipLength=0.2)



def getStrokes(font : np.ndarray):
    h, w = font.shape
    hmap = np.zeros((h + 1, w + 1))
    vmap = np.zeros((h + 1, w + 1))
    
    img = np.zeros((600,600,3), dtype=np.uint8)

    
    RIGHT = DOWN = 1
    LEFT = UP = -1
    
    PROCESSED = 2
    
    NO_MOVE = 0
    GO_RIGHT = 1
    GO_LEFT = 2
    GO_UP = 3
    GO_DOWN = 4
    
    for y in range(h):
        for x in range(w):
            if font[y, x] == 1:
                hmap[y    , x] += RIGHT
                hmap[y + 1, x] += LEFT
                vmap[y    , x] += UP
                vmap[y, x + 1] += DOWN
    
    strokes = []
    processed = hmap.copy()
    #find contours:
    for y0 in range(h):
        for x0 in range(w):
            last_move = NO_MOVE
            previous_move = NO_MOVE
            x = x0
            y = y0
            if hmap[y, x] == RIGHT and processed[y, x] != PROCESSED:
                #can go right here
                x = x0 + 1
                contour = [(x0,y0),(x,y)]
            
                processed[y0, x0] = PROCESSED
                last_move = GO_RIGHT
                while (x,y) != contour[0]:
                    previous_move = last_move
                    if last_move == GO_RIGHT: #tries to go down soon
                        if vmap[y,x] == DOWN:
                            y += 1; last_move = GO_DOWN
                        elif vmap[y-1,x] == UP and y >= 1:
                            y -= 1; last_move = GO_UP
                        elif hmap[y,x] == RIGHT and x < w:
                            assert processed[y,x] != PROCESSED
                            processed[y,x] = PROCESSED
                            x += 1; last_move = GO_RIGHT
                            
                        else:
                            raise AssertionError('Unexpected end of path')
                    elif last_move == GO_DOWN: #tries to go left soon
                        if x >= 1 and hmap[y, x-1] == LEFT and processed[y,x-1] != PROCESSED:
                            processed[y, x-1] = PROCESSED
                            x -= 1; last_move = GO_LEFT
                        elif hmap[y,x] == RIGHT and processed[y,x] != PROCESSED:
                            processed[y, x] = PROCESSED
                            x += 1; last_move = GO_RIGHT
                        elif vmap[y,x] == DOWN and y < h:
                            y += 1; last_move = GO_DOWN
                        else:
                            raise AssertionError('Unexpected end of path')
                    elif last_move == GO_LEFT: #tries to go up soon
                        if y >= 1 and vmap[y-1, x] == UP:
                            y -= 1; last_move = GO_UP
                        elif vmap[y,x] == DOWN and y < h:
                            y += 1; last_move = GO_DOWN
                        elif x >= 1 and hmap[y,x-1] == LEFT:
                            assert processed[y,x-1] != PROCESSED
                            processed[y, x-1] = PROCESSED
                            x -= 1; last_move = GO_LEFT
                        else:
                            raise AssertionError('Unexpected end of path')
                    elif last_move == GO_UP: #tries to go right soon
                        if x <= w and hmap[y,x] == RIGHT and processed[y,x] != PROCESSED:
                            processed[y, x] = PROCESSED
                            x += 1; last_move = GO_RIGHT
                        elif x >= 1 and hmap[y,x-1] == LEFT and processed[y,x-1] != PROCESSED:
                            processed[y, x-1] = PROCESSED
                            x -= 1; last_move = GO_LEFT
                        elif y >= 1 and vmap[y-1, x] == UP:
                            y -= 1; last_move = GO_UP
                        else:
                            raise AssertionError('Unexpected end of path')
                    
                    oldx, oldy  = contour[-1]
                    assert oldx != x or oldy != y
                    if previous_move == last_move:
                        contour[-1] = (x, y)
                    else:
                        contour.append((x, y))
                    img = np.zeros_like(img)
                    prev(processed,img,vmap)
                    cv.imshow('test', img)
                    cv.waitKey(2)
                strokes.append(contour)
                
    cv.destroyAllWindows()

    return strokes


def drawto(p,canvas,c):
    global drawx,drawy
    drawline((drawx,drawy),p,canvas,c)
    drawx = p[0]
    drawy = p[1]

def drawline(p0,p1,canvas : np.ndarray | None = None,c = (255,255,255)):
    if canvas is not None:
        x0,y0 = p0
        x1,y1 = p1
        cv.line(canvas,(x0,y0 + 10),(x1,y1 + 10),c,2)

def drawstrokes(strokes,canvas : np.ndarray | None = None):
    global drawx,drawy,count
    for stroke in strokes:
        print('new stroke')
        drawx,drawy = stroke[0]
        drawx *= px
        drawy *= px
        for point in stroke[1:]:
            x, y = point
            c = (0,0,0)
            if count % 3 == 0:c = (255,0,0)
            if count % 3 == 1:c = (0,255,0)
            if count % 3 == 2:c = (0,0,255)
            
            count += 1
            drawto((x*px,y*px),canvas,c)
            cv.imshow('test',canvas)
            cv.waitKey(0)
    
    cv.destroyAllWindows()






def genFnt():
    fnt = np.zeros((16,16), dtype=np.uint8)
    
    #load image from str
    font = '001070208840808081008A0076010A4D125222924312828C0248024E0011000E'
    fontwidth = 0

    if len(font) == 32:
        fontwidth = 8
    else:
        fontwidth = 16
    
    seeker = 0x01
    for i in range(16):
        line_byte = 0x0
        if fontwidth == 8:
            line_byte = int(font[i*2:i*2+2],16)
        else:
            line_byte = int(font[i*4:i*4+4],16)

        for j in range(fontwidth):
            if line_byte & (seeker << j):
                fnt[i][fontwidth  - j - 1] = 1
            else:
                fnt[i][fontwidth - j - 1] = 0

    return fnt


if __name__ == "__main__":
    img = np.zeros((600,600,3),dtype=np.uint8)
    #fnt = genFnt()
    with open('./font/test.bdf','rb') as fp:
        font = reader.read_bdf(fp)
        g = font.glyphs[0x4e3f]
        
        print(g.bbW)
        print(g.bbX,g.bbY)
        
        fnt = bitmapFromBDF(g.__str__())
        print(fnt)
        s = getStrokes(fnt)
        print(s)
        drawstrokes(s,img)
    

