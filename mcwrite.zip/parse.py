from lxml import etree
from html.parser import HTMLParser
from json import JSONEncoder

from constants import Signtypes


def trim_command(command : str) -> str:
    '''
    Trim the command string so it will fit in command
    '''
    command = command.replace("'","\\'") # ' -> \'
    command = command.replace('"','\\"') # " -> \\"
    #command = command.replace('\\','\\\\"') #\ -> \\
    return command

def trim_text(text : str) -> str:
    '''
    Trim the text so it will fit in command
    '''
    text = text.replace("'","\\'")# ' -> \'
    text = text.replace('"','\\\\"')# " -> \\"
    return text

class MyHTMLParser(HTMLParser):
    tree : list #lines of a single face
    
    #current state of the text being processed
    current_color : str
    current_bold : bool
    current_italic : bool
    current_underline : bool
    current_strike : bool
    
    current_line : list #a line in a single face
    in_content : bool #is here content? (rather than head)
    line_count: int #number of the current line
    
    commands : list #commands to be embedded in the json
    
    def reset_attr(self): #reset all attributes
        self.current_color = ''
        self.current_bold = False
        self.current_italic = False
        self.current_underline = False
        self.current_strike = False
    
    def __init__(self):
        super().__init__()
        self.tree = []
        self.reset_attr()
        self.line_count = 0
        
        self.in_content = False

    def parse(self, html : str):
        '''
        Parse html
        '''
        self.line_count = 0
        self.feed(html)

        if self.line_count < len(self.commands):
            #there are some command lines without text lines
            #so we will create empty text lines to embed commands
            for i in range(self.line_count, len(self.commands)):
                cmd = self.commands[i]
                if cmd != '': self.current_line.append({'command': cmd})
    
    def set_command(self, commands : list):
        '''
        Set commands for the face
        :param commands: List of commands, one command per item
        '''
        self.commands = commands
    
    def handle_starttag(self, tag, attrs):
        if tag == 'p': #start of a line     
            self.in_content = True #in content now, start processing data
            self.current_line = [] #create a new line
            
            #embed command
            if len(self.commands) > self.line_count: #there's a command to be embedded in this line
                cmd = self.commands[self.line_count]
                if cmd != '': # command makes sense
                    #cmd = trim_command(cmd)
                    self.current_line.append({'command' : cmd})
            
            self.tree.append(self.current_line) 
            self.reset_attr()
            self.line_count += 1
        
        if tag =='br': #nothing in this line
            pass
                
        if tag == 'span': #a text block with attributes
            if attrs == None:
                return
            for attr, value in attrs:
                #print('[%s]>%s'%(attr,value))
                if 'font-weight:600' in value:
                    self.current_bold = True
                if 'italic' in value:
                    self.current_italic = True
                if 'line-through' in value:
                    self.current_strike = True
                if 'underline' in value:
                    self.current_underline = True
                if 'color:#' in value:
                    pos = value.find('color:#')
                    self.current_color = value[pos + 6:pos +13]
                    #current_color should be like: #000000
                    
    def handle_endtag(self, tag):
        self.reset_attr() #reset attributes after finishing processing the tag
    
    def handle_data(self, data):
        if self.in_content:
            if data != '\n' and data != '':#data makes sense
                text_part = {'text':data}
                if self.current_bold:
                    text_part['bold'] = True
                if self.current_italic:
                    text_part['italic'] = True
                if self.current_underline:
                    text_part['underline'] = True
                if self.current_strike:
                    text_part['strikethrough'] = True
                if self.current_color != '':
                    text_part['color']=self.current_color
                
                self.current_line.append(text_part)
                
    def result(self):
        return self.tree
    
    def clearHTML(self):
        self.tree.clear()
        self.reset_attr()
        self.in_content = False
        self.commands = []
        return super().reset()
    

def htmlToJsontext(htm: str):
    html = MyHTMLParser()
    html.feed(htm)
    print(html.tree)

def hasProperty(comp : dict,property : str):
    if property in comp.keys():
        if isinstance(comp[property],list):
            return len(comp[property]) > 0
        if isinstance(comp[property],dict):
            return not comp[property].isEmpty()
        return comp[property] != False and comp[property] is not None
    return False



def treeToCommand120(tree : dict):
    #/give @a oak_sign{BlockEntityTag:{front_text:
    # {messages:['["test"]','[""]','[""]','[""]']}},
    # display:{Name:'["",{"text":"test","italic":false}]'}}

    def treeToFace120(tree : list):
        i = 0
        temp = '{messages:[%s]}'
        result_commands = ''
        for i in range(4):
            if i >= len(tree): #no more lines
                line_result = "'[\"\"]'"
                result_commands += line_result
                if i < 3: result_commands += ','  # not the last line, append a ',' to command
                continue
            line = tree[i]
            line : list
            if i >= 4: break
            line_result ="'[%s]'"
            line_commands = ''

            comp_count = len(line)
            if comp_count == 0: #nothing in this line
                line_result = line_result%'""'
                result_commands += line_result
                if i < 3: result_commands += ','#not the last line, append a ',' to command
                continue

            for j in range(comp_count):
                comp_command = ''
                comp = line[j]
                comp : dict
                text = ''
                if 'text' in comp.keys():
                    text = comp['text']
                    text = trim_text(text)
                else:
                    text = ''

                is_bold = hasProperty(comp, 'bold')
                is_italic = hasProperty(comp, 'italic')
                is_underline = hasProperty(comp, 'underline')
                is_strike = hasProperty(comp, 'strikethrough')
                is_color = hasProperty(comp, 'color')
                is_command = hasProperty(comp, 'command')
                if not (is_bold or is_italic or is_underline or is_strike or is_color or is_command):
                    #no property at all
                    comp_command = '"%s"'
                    comp_command = comp_command%trim_text(text)
                    line_commands += comp_command
                    if j < comp_count - 1: line_commands += ','  # not the last component

                else:
                    comp_command = '{"text":"%s"' #no }
                    comp_command = comp_command%trim_text(text)
                    if is_bold: comp_command += ',"bold":true'
                    if is_italic: comp_command += ',"italic":true'
                    if is_underline: comp_command += ',"underline":true'
                    if is_strike: comp_command += ',"strikethrough":true'
                    if is_color: comp_command += ',"color":"%s"'%comp['color']
                    if is_command:
                        command_temp = ',"clickEvent":{"action":"run_command","value":"%s"}'
                        embedded_command = comp['command']
                        embedded_command = trim_command(embedded_command)
                        comp_command += command_temp %  embedded_command
                    comp_command += '}'
                    line_commands += comp_command
                    if j < comp_count - 1: line_commands += ','  # not the last component

            line_result = line_result%line_commands
            result_commands += line_result
            if i < 3: result_commands += ','  # not the last line, append a ',' to command
            continue
        return temp % result_commands

    commandbase = "/give @p %s{BlockEntityTag:{%s%s%s},display:{Name:'{\"text\":\"%s\"}'}}"
    name = 'sign'
    signtype = 'oak_sign'
    waxed = ''
    try:
        name = tree['name']
        signtype = tree['type']
    except:
        pass

    front_temp = ''
    back_temp = ''
    if hasProperty(tree, 'front_text'):
        front_temp = 'front_text:%s'
        front_command = treeToFace120(tree['front_text'])
        front_temp = front_temp % front_command
    if hasProperty(tree, 'back_text'):
        back_temp = 'back_text:%s'
        if hasProperty(tree, 'front_text'):#has both side
            back_temp = ',' + back_temp
        back_command = treeToFace120(tree['back_text'])
        back_temp = back_temp % back_command
    if hasProperty(tree, 'waxed'):
        waxed = 'is_waxed:1'
        if hasProperty(tree, 'front_text') or hasProperty(tree, 'back_text'):
            waxed = ',is_waxed:1'
    commandbase = commandbase%(signtype,front_temp,back_temp,waxed,name)
    return commandbase


    #front and back text