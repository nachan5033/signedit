import sys

import platform
from sign_text_edit import SignTextEdit
from mcedit import MCEdit, SignEdit
from signeditpanel import SignEditPanel, SignInfoEditor
from constants import *
from younyao_in import YounyaoIn
from insert_pic import PicInsert
from cmd2htm import parseCommand

from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QKeySequence,QFont,QTextCursor,QColor,QIcon,QTextCharFormat,QClipboard,QTextDocumentFragment,QTextBlock

from lxml import etree

class mainwin(QMainWindow):
    edit_panel : SignEditPanel
    sign_info : SignInfoEditor
    app : QApplication
    toolbar : QToolBar
    
    bold   :    QAction
    italic :    QAction
    underline   : QAction
    strikeline  : QAction
    younyao_in  : QAction
    fontcombo : QComboBox
    textcolor   : QWidgetAction
    colorbutton : QToolButton
    special_char: QWidget
    insert      : QAction
    
    def __init__(self, app):
        super().__init__()
        self.app = app
        self.edit_panel = SignEditPanel(parent=self)
        self.sign_info = SignInfoEditor(parent=self)
        self.sign_info_dock = QDockWidget('Sign Info', self)
        self.sign_info_dock.setWidget(self.sign_info)
        
        self.setCentralWidget(self.edit_panel)
        self.addDockWidget(Qt.RightDockWidgetArea, self.sign_info_dock)

        self.setGeometry(300, 300, win_width, win_height)
        self.setWindowTitle('Minecraft Sign Generator')
        
        self.createToolBar()

    def createToolBar(self):
        self.toolbar = self.addToolBar('Toolbar')

        #bold
        self.bold = QAction(self)
        self.bold.setText("B")
        self.bold.setShortcut(QKeySequence.Bold)
        self.bold.setToolTip("Bold")
        self.bold.setCheckable(True)
        font1 = QFont("minecraft",pointSize=18);font1.setBold(True)
        self.bold.setFont(font1)
        self.bold.triggered.connect(self.onBold)

        #italic
        self.italic = QAction(self)
        self.italic.setText("I")
        self.italic.setShortcut(QKeySequence.Italic)
        self.italic.setToolTip("Italic")
        self.italic.setCheckable(True)
        self.italic.setFont(QFont("minecraft",pointSize=18,italic=True))
        self.italic.triggered.connect(self.onItalic)

        self.underline = QAction(self)
        self.underline.setText("U")
        self.underline.setShortcut(QKeySequence.Underline)
        self.underline.setToolTip("Underline")
        self.underline.setCheckable(True)
        font2 = QFont("minecraft",pointSize=18);font2.setUnderline(True)
        self.underline.setFont(font2)
        self.underline.triggered.connect(self.onUnderline)

        #Strikeline
        self.strikeline = QAction(self)
        self.strikeline.setText("S")
        self.strikeline.setToolTip("Strikeline")
        self.strikeline.setCheckable(True)
        font3 = QFont("minecraft",pointSize=18);font3.setStrikeOut(True)
        self.strikeline.setFont(font3)
        self.strikeline.triggered.connect(self.onStrikeline)

        #font selector
        self.fontcombo = QComboBox()
        self.createFontCombo(self.fontcombo)
        self.fontcombo.activated.connect(self.onFontChanged)

        #color
        self.textcolor = QWidgetAction(self.toolbar)
        font4 = QFont("Minecraft",pointSize=18)

        self.colorbutton = QToolButton(self)
        self.colorbutton.setText("C")
        self.colorbutton.setFont(font4)
        self.colorbutton.setStyleSheet("color: green")
        self.colorbutton.setPopupMode(QToolButton.InstantPopup)
        self.colorbutton.setAutoRaise(True)

        menu = QMenu(self.colorbutton)
        self.createColorMenu(menu)
        self.colorbutton.setMenu(menu)

        self.textcolor.setToolTip("Color")
        self.textcolor.setDefaultWidget(self.colorbutton)

        self.younyao_in   = QAction("音")
        self.younyao_in.setToolTip("有鳥音轉換")
        font5 = QFont("Minecraft,unifont",pointSize=18,italic=True);font5.setBold(True)
        self.younyao_in.setFont(font5)
        self.younyao_in.setCheckable(False)
        self.younyao_in.triggered.connect(self.onYounyaoInPopup)
        
        self.insert   = QAction("P")
        self.insert.setToolTip("Insert Image")
        font5 = QFont("Minecraft,unifont",pointSize=18,italic=True);font5.setBold(True)
        self.insert.setFont(font5)
        self.insert.setCheckable(False)
        self.insert.triggered.connect(self.onInsert)




        self.textcolor.setToolTip("Color")
        self.textcolor.setDefaultWidget(self.colorbutton)

        self.toolbar.addAction(self.bold)
        self.toolbar.addAction(self.italic)
        self.toolbar.addAction(self.underline)
        self.toolbar.addAction(self.strikeline)
        self.toolbar.addWidget(self.fontcombo)
        self.toolbar.addSeparator()
        self.toolbar.addAction(self.textcolor)
        self.toolbar.addAction(self.younyao_in)
        self.toolbar.addAction(self.insert)


        self.toolbar.setStyleSheet("QToolBar { spacing: 2px; }")

    def createColorMenu(self, menu: QMenu) -> None:
        global colors, desp

        layout = QGridLayout()
        layout.setContentsMargins(4, 4, 4, 4)
        widget = QWidget()

        for i in range(len(colors)):
            col = QToolButton(menu)
            col.setText(" ")
            col.setStyleSheet("background-color: %s; width:8; height:10" % colors[i])
            col.setToolTip(desp[i])

            action = QAction(col)
            action.setCheckable(False)
            action.triggered.connect(self.onColorClick)
            col.setDefaultAction(action)
            layout.addWidget(col, i // 8, i % 8)

        widget.setLayout(layout)

        action = QWidgetAction(menu)
        action.setDefaultWidget(widget)
        menu.addAction(action)
        menu.setStyleSheet("color: black")
        menu.addSeparator()
        more = QAction("More Color...", menu)
        more.triggered.connect(self.onMoreColorClick)
        menu.addAction(more)

    def createFontCombo(self, combo: QComboBox) -> None:
        global fonts_name
        combo.clear()
        for font in fonts_name:
            combo.addItem(font)
        combo.setCurrentIndex(0)


    def onColorClick(self):
        textpanel = self.edit_panel.text_panel
        cursor: QTextCursor = textpanel.textCursor()
        sender = self.sender().sender().parent()
        style = sender.styleSheet()
        color = style[18:25]

        if not cursor.selection().isEmpty():
            cursor.beginEditBlock()
            textformat = QTextCharFormat()
            textformat.setForeground(QColor(color))
            cursor.mergeCharFormat(textformat)
            cursor.endEditBlock()
        else:
            textpanel.setTextColor(QColor(color))

    def onMoreColorClick(self):
        textpanel = self.edit_panel.text_panel
        cursor: QTextCursor = textpanel.textCursor()

        dlg = QColorDialog(textpanel.textColor(), self)
        # dlg.show()
        color = dlg.getColor()
        dlg.close()

        if not cursor.selection().isEmpty():
            cursor.beginEditBlock()
            print(self.hasFocus())
            textformat = QTextCharFormat()
            textformat.setForeground(color.toRgb())
            cursor.mergeCharFormat(textformat)
            cursor.endEditBlock()
        else:
            textpanel.setTextColor(color)

    def onYounyaoInPopup(self):
        self.in_win = YounyaoIn(self.app)
        self.in_win.show()

    def onInsert(self):
        self.dialog = PicInsert(self,"")
        self.dialog.show()

    def onBold(self, ischecked):
        textpanel = self.edit_panel.text_panel
        cursor : QTextCursor = textpanel.textCursor()

        if not cursor.selection().isEmpty():
            cursor.beginEditBlock()
            textformat = QTextCharFormat()
            if ischecked:
                textformat.setFontWeight(75)
            else:
                textformat.setFontWeight(50)
            cursor.mergeCharFormat(textformat)
            cursor.endEditBlock()
        else:
            if ischecked:
                textpanel.setFontWeight(75)
            else:
                textpanel.setFontWeight(50)

    def onItalic(self, ischecked):
        textpanel = self.edit_panel.text_panel
        cursor : QTextCursor = textpanel.textCursor()

        if not cursor.selection().isEmpty():
            cursor.beginEditBlock()
            textformat = QTextCharFormat()
            if ischecked:
                textformat.setFontItalic(True)
            else:
                textformat.setFontItalic(False)
            cursor.mergeCharFormat(textformat)
            cursor.endEditBlock()
        else:
            if ischecked:
                textpanel.setFontItalic(True)
            else:
                textpanel.setFontItalic(False)

    def onUnderline(self, ischecked):
        textpanel = self.edit_panel.text_panel
        cursor : QTextCursor = textpanel.textCursor()

        if not cursor.selection().isEmpty():
            cursor.beginEditBlock()
            textformat = QTextCharFormat()
            if ischecked:
                textformat.setFontUnderline(True)
            else:
                textformat.setFontUnderline(False)
            cursor.mergeCharFormat(textformat)
            cursor.endEditBlock()
        else:
            if ischecked:
                textpanel.setFontUnderline(True)
            else:
                textpanel.setFontUnderline(False)

    def onStrikeline(self, ischecked):
        global pointSize
        textpanel = self.edit_panel.text_panel
        cursor : QTextCursor = textpanel.textCursor()

        if not cursor.selection().isEmpty():
            cursor.beginEditBlock()
            textformat = QTextCharFormat()
            if ischecked:
                textformat.setFontStrikeOut(True)
            else:
                textformat.setFontStrikeOut(False)
            cursor.mergeCharFormat(textformat)
            cursor.endEditBlock()
        else:
            font = QFont("minecraft",pointSize=point_size)
            if ischecked:
                font.setStrikeOut(True)
            else:
                font.setStrikeOut(False)
            textpanel.setCurrentFont(font)

    def onCursorPosChanged(self):
        textpanel = self.edit_panel.text_panel
        self.italic.setChecked(textpanel.fontItalic())
        self.underline.setChecked(textpanel.fontUnderline())
        font = textpanel.currentFont()
        self.strikeline.setChecked(font.strikeOut())
        self.bold.setChecked(font.bold())

    def onFontChanged(self,index):
        self.edit_panel.text_panel.font = index #set auto font conversion of mcedit

        cursor = self.edit_panel.text_panel.textCursor()
        if not cursor.selection().isEmpty(): #some text selected, convert them to specific font
            start = cursor.selectionStart()
            end = cursor.selectionEnd()

            texts = cursor.selectedText()
            new_text = mapFont(texts,index)

            cursor.beginEditBlock()
            cursor.setPosition(start,QTextCursor.MoveAnchor)
            #replace old characters with new ones
            for i in range(len(texts)):
                org_pos = cursor.position()
                cursor.setPosition(org_pos + 1, QTextCursor.MoveAnchor)
                format = cursor.charFormat()
                cursor.setPosition(org_pos, QTextCursor.MoveAnchor)
                cursor.deleteChar()

                cursor.insertText(new_text[i],format)
            cursor.endEditBlock()
            cursor.setPosition(start)
            cursor.setPosition(start + len(new_text.encode('utf-8')) ,QTextCursor.KeepAnchor)
            self.edit_panel.text_panel.setTextCursor(cursor)



def mapFont(text : str, target : Fonts):
    '''
    Map given text to target font
    @param text: text to map
    @param target: target font
    '''
    global fonts_mapping
    result = ''
    for c in text:
        #faster mapping method if text is in ASCII
        if ord('a') <= ord(c) <= ord('z'):
            index = ord(c) - ord('a')
            result += fonts_mapping[target][index]
            continue
        if ord('A') <= ord(c) <= ord('Z'):
            index = ord(c) - ord('A')
            result += fonts_mapping[target][index + 26]
            continue
        if ord('0') <= ord(c) <= ord('9'):
            index = ord(c) - ord('0')
            result += fonts_mapping[target][index + 52]
            continue

        #character not in ASCII
        conv_c = ''
        for available_font in fonts_mapping:
            if c in available_font:
                index = available_font.find(c)
                conv_c = fonts_mapping[target][index]
                break

        if conv_c == '':
            result += c # no match
        else:
            result += conv_c
    return result


def main():
    global point_size,win_width,win_height
    if platform.system() == "Windows":
        point_size = 36;win_width=1200;win_height=600
    elif platform.system() == "Darwin":
        point_size = 24;win_width=1000;win_height=500
    else:
        point_size = 24;win_width=1000;win_height=500

    app = QApplication(sys.argv)
    win = mainwin(app)
    win.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
    