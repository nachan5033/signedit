from constants import *
from insert_pic import PicInsert
from parse import *

from PyQt5.QtWidgets import QTextEdit, QTextBrowser, QWidget
from PyQt5.QtCore import QMimeData,Qt,QUrl
from PyQt5.QtGui import QTextCharFormat,QTextBlockFormat
from PyQt5 import QtGui

import json

class Sign:
    name : str
    type : str
    font : Fonts

    front_HTML :str
    back_HTML : str

    front_commands : list
    back_commands : list
    both_commands : list#temp command list for BOTH mode

    face_mode: Facemodes

    def __init__(self):
        pass


class MCEdit(QTextEdit):
    font : Fonts
    parser : MyHTMLParser
    
    def __init__(self, parent : QWidget | None):
        super().__init__(parent)
        
        self.font = Fonts.NORMAL
        self.parser = MyHTMLParser()
    
    def keyPressEvent(self, ev):
        if self.font == Fonts.NORMAL:
            return super().keyPressEvent(ev)
        
        else: #special font mode, capture input
            chr : str
            if len(ev.text()) != 1: #no input
                return super().keyPressEvent(ev)
            chr = ev.text()[0]
            mapping = fonts_mapping[self.font]
                
            if 'a' <= chr <= 'z': #lower case
                index = ord(chr) - ord('a') #find where the character is in the mapping
                self.insertPlainText(mapping[index])
                ev.ignore()
                
            elif 'A' <= chr <= 'Z': #upper case
                index = ord(chr) - ord('A') + 26
                self.insertPlainText(mapping[index])
                ev.ignore()
            
            elif '0' <= chr <= '9':
                index = ord(chr) - ord('0') + 52
                self.insertPlainText(mapping[index])
                ev.ignore()
            
            else:
                return super().keyPressEvent(ev)
        return
    
    def getJsonText(self) -> str:
        return ''
    
    def insertFromMimeData(self, source: QMimeData | None) -> None:
        global point_size
        newdata = QMimeData()
        if source.hasHtml():
            html = source.html()
    
            doc = QTextEdit()
            doc.setHtml(html)

            textformat = QTextCharFormat()
            textformat.setFontFamilies(["minecraft","unifont"])
            textformat.setFontPointSize(point_size - 14)
            textformat.clearBackground()

            block  = QTextBlockFormat()
            block.clearBackground()
            block.setAlignment(Qt.AlignCenter)

            cursor = doc.textCursor()
            cursor.select(QtGui.QTextCursor.Document)
            cursor.setBlockFormat(block)
            cursor.mergeCharFormat(textformat)
            
            newdata.setHtml(doc.toHtml())
            return super().insertFromMimeData(newdata)
        elif source.hasUrls():
            path :str = source.urls()[0].toString()
            if path.startswith("file://"):
                path = path[7:]
            self.insert_panel = PicInsert(self.parent().parent(),path)
            self.insert_panel.show()
        else:
            return super().insertFromMimeData(source)

class SignEdit(MCEdit):
    face_mode : Facemodes
    front_html : str
    back_html : str
    
    front_command: list
    back_command: list
    both_command: list #temp command list for BOTH mode
    
    sign_type : str
    sign_name : str
    
    def __init__(self, parent):
        global point_size
        
        super().__init__(parent)
        self.setLineWrapMode(QTextEdit.NoWrap)
        self.setMinimumHeight(250)
        
        self.face_mode = Facemodes.FRONT
        self.front_html = ''
        self.back_html = ''
        
        self.sign_type = 'oak_sign'
        self.sign_name = 'Custom sign'

        self.front_command = []
        self.back_command = []

        self.waxed = False
        
        self.syncStyle()
        
    
    def syncStyle(self):
        sheet = """QTextEdit { background-color: lightgray;
                                       font-size: %dpx; 
                                      font-family: 'minecraft','unifont';
                                      padding: 0;
                                      margin-bottom: 0px;
                                      background: url("./src/oak.png") repeat top center;
                                      }""" % point_size

        self.setStyleSheet(sheet)
        self.setAlignment(Qt.AlignCenter)
    
    def setHtml(self, text):
        if text == '': #no html, just clear the page
            self.clear()
            self.syncStyle()
            return
        return super().setHtml(text)
    
    def frontMode(self):
        if self.face_mode == Facemodes.BACK:#switch from back mode
            self.back_html = self.toHtml() #storage back html
            self.face_mode = Facemodes.FRONT
            self.setHtml(self.front_html)
            
            
        elif self.face_mode == Facemodes.BOTH: #switch from both mode
            self.front_html = self.toHtml() #sync front html
            self.front_command = self.both_command #sync front command
            self.face_mode = Facemodes.FRONT
        
    
    def backMode(self):
        if self.face_mode == Facemodes.FRONT:#switch from front mode
            self.front_html = self.toHtml() #storage front html
            self.face_mode = Facemodes.BACK
            self.setHtml(self.back_html)
            
        
        elif self.face_mode == Facemodes.BOTH: #switch from both mode
            self.back_html = self.toHtml() #sync back html
            self.back_command = self.both_command #sync back command
            self.face_mode = Facemodes.BACK
    
    def bothMode(self):
        if self.face_mode == Facemodes.FRONT:
            self.both_command = self.front_command
        elif self.face_mode == Facemodes.BACK:
            self.both_command = self.back_command

        self.face_mode = Facemodes.BOTH

    def getJsonTree(self):
        json_obj = {'name' : self.sign_name, 'type':self.sign_type}
        if self.waxed:
            json_obj['waxed'] = True
        result = ''
        
        if self.face_mode == Facemodes.BOTH:
            self.parser.set_command(self.both_command)
            self.parser.parse(self.toHtml())
            text_obj = self.parser.result()
            json_obj['front_text'] = text_obj
            json_obj['back_text'] = text_obj
            #result = json.dumps(json_obj)
            self.parser.clearHTML()
        else:
            if self.face_mode == Facemodes.FRONT: #sync front and back html
                self.front_html = self.toHtml()
            else:
                self.back_html = self.toHtml()

            self.parser.set_command(self.front_command)
            self.parser.parse(self.front_html)
            front_obj = self.parser.result().copy() #prevent it from deleting by clearHTML()
            json_obj['front_text'] = front_obj
            self.parser.clearHTML()

            self.parser.set_command(self.back_command)
            self.parser.parse(self.back_html)
            back_obj = self.parser.result()
            json_obj['back_text'] = back_obj
            
            #result = json.dumps(json_obj)
            self.parser.clearHTML()
        
        return json_obj

    def getJsonText(self):
        obj = self.getJsonTree()
        return json.dumps(obj)

    def getCommand120(self):
        obj = self.getJsonTree()
        return treeToCommand120(obj)

    def getCommand121(self):
        return 'Not implemented'

    def set_commands(self, face : Facemodes, commands: list):
        '''
        Set commands of the sign
        :param face: Face to set commands
        :param commands: list of commands
        '''

        if face == Facemodes.FRONT: self.front_command = commands
        elif face == Facemodes.BACK: self.back_command = commands
        elif face == Facemodes.BOTH: self.both_command = commands

    def set_commands_for_current_face(self, commands: list):
        '''
        Set commands of the current face of the sign
        :param commands: list of commands
        '''

        if self.face_mode == Facemodes.FRONT: self.front_command = commands
        elif self.face_mode == Facemodes.BACK: self.back_command = commands
        elif self.face_mode == Facemodes.BOTH: self.both_command = commands
        
    def getCommandForCurrentFace(self) -> list:
        if self.face_mode == Facemodes.FRONT: return self.front_command
        if self.face_mode == Facemodes.BACK: return self.back_command
        if self.face_mode == Facemodes.BOTH: return self.both_command
        return []

class SignPicker(QWidget):
    pass